package ClothingStore.Member3_Sales_And_Billing;

import ClothingStore.Member2_Inventory_Management.InventoryItem;
import ClothingStore.Member2_Inventory_Management.InventoryManager;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class SalesManager {
    private InventoryManager inventoryManager;
    private List<Sale> sales;
    // Constructor
    public SalesManager(InventoryManager inventoryManager) {
        this.inventoryManager = inventoryManager;
        this.sales = new ArrayList<>();
    }
    

    public void recordSale(Sale sale) {
        sales.add(sale);
    }

    public void recordSale(List<InventoryItem> items, String customerName) {
        int id = sales.size() + 1;
        double total = 0;
        for (InventoryItem item : items) {
            total += item.getPrice();
        }
        Sale sale = new Sale(id, total, LocalDate.now().toString(), items, customerName);
        recordSale(sale);
    }

    public double getDailyTotal(String date) {
        double total = 0;
        for (Sale s : sales) {
            if (s.getDate().equals(date)) {
                total += s.getTotalAmount();
            }
        }
        return total;
    }

    public List<Sale> getAllSales() {
        return sales;
    }

    public InventoryItem getProductById(int productId) {
        return inventoryManager.searchById(productId);
    }

    public List<InventoryItem> getAllProducts() {
        return inventoryManager.getItems();
    }

    public Sale getSaleById(int transactionId) {
        for (Sale sale : sales) {
            if (sale.getTransactionID() == transactionId) {
                return sale;
            }
        }
        return null;
    }
}
