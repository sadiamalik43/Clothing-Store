package ClothingStore.Member3_Sales_And_Billing;

import ClothingStore.Member2_Inventory_Management.InventoryManager;
import ClothingStore.Member2_Inventory_Management.InventoryItem;
import java.util.*;

public class Main3 {
    private static Scanner scanner = new Scanner(System.in);
    private static InventoryManager inventoryManager = new InventoryManager();
    private static SalesManager manager = new SalesManager(inventoryManager);

    public static void main(String[] args) {
        int choice;

        do {
            System.out.println("\n===== Clothing Store Sales System =====");
            System.out.println("1. Add New Sale");
            System.out.println("2. View All Sales");
            System.out.println("3. Print Invoice for a Sale");
            System.out.println("4. Get Daily Total Sales");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // clear buffer

            switch (choice) {
                case 1:
                    recordNewSale();
                    break;
                case 2:
                    viewAllSales();
                    break;
                case 3:
                    printInvoice();
                    break;
                case 4:
                    getDailyTotal();
                    break;
                case 5:
                    System.out.println("Exiting... Thank you!");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }

        } while (choice != 5);
    }

    private static void recordNewSale() {
        List<InventoryItem> items = new ArrayList<>();
        System.out.print("Enter customer name: ");
        String customerName = scanner.nextLine();

        while (true) {
            System.out.println("Available Products:");
            for (InventoryItem item : manager.getAllProducts()) {
                System.out.println(item);
            }

            System.out.print("Enter Product ID to add to sale: ");
            int productId = scanner.nextInt();
            scanner.nextLine(); // clear buffer

            InventoryItem item = manager.getProductById(productId);
            if (item != null) {
                items.add(item);
                System.out.println("Product added: " + item.getName());
            } else {
                System.out.println("Product not found. Please try again.");
            }

            System.out.print("Add another product? (y/n): ");
            String more = scanner.nextLine();
            if (!more.equalsIgnoreCase("y")) break;
        }

        manager.recordSale(items, customerName);
        System.out.println("Sale recorded successfully.");
    }

    private static void viewAllSales() {
        List<Sale> sales = manager.getAllSales();
        if (sales.isEmpty()) {
            System.out.println("No sales recorded.");
            return;
        }

        for (Sale s : sales) {
            System.out.println("Transaction ID: " + s.getTransactionID() +
                    ", Customer: " + s.getCustomerName() +
                    ", Total: " + s.getTotalAmount() +
                    ", Date: " + s.getDate());
        }
    }

    private static void printInvoice() {
        System.out.print("Enter Transaction ID to print invoice: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // clear buffer

        Sale sale = manager.getSaleById(id);
        if (sale != null) {
            sale.printInvoice();
        } else {
            System.out.println("Sale not found.");
        }
    }

    private static void getDailyTotal() {
        System.out.print("Enter date (YYYY-MM-DD): ");
        String date = scanner.nextLine();

        double total = manager.getDailyTotal(date);
        System.out.println("Total sales for " + date + ": " + total);
    }
}
