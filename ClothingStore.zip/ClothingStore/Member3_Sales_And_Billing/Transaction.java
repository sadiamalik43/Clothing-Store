package ClothingStore.Member3_Sales_And_Billing;

public abstract class Transaction {
    protected int transactionID;
    protected double totalAmount;
    protected String date;

    public Transaction(int transactionID, double totalAmount, String date) {
        this.transactionID = transactionID;
        this.totalAmount = totalAmount;
        this.date = date;
    }

    public int getTransactionID() {
        return transactionID;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public String getDate() {
        return date;
    }

    public abstract void printInvoice();
}
