package ClothingStore.Member3_Sales_And_Billing;

import java.util.ArrayList;
import java.util.List;

import ClothingStore.Member2_Inventory_Management.InventoryItem; // Import InventoryItem instead of Product
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.scene.Scene;

public class Member3UI {
    private VBox optionBox;
    private Label selectedOptionLabel = null;
    private Popup popup;
    private SalesManager salesManager;

    public Member3UI(SalesManager salesManager) {
        this.salesManager = salesManager;
        popup = new Popup();
        popup.setAutoHide(true);
        buildPopup();
    }

    private void buildPopup() {
        optionBox = new VBox();
        optionBox.setAlignment(Pos.TOP_LEFT);
        optionBox.setPadding(new Insets(0, 5, 5, 5));
        optionBox.setSpacing(0);

        Label addSaleOpt = makeOptionLabel("Add New Sale", true);
        Label viewSalesOpt = makeOptionLabel("View All Sales", false);
        Label printInvoiceOpt = makeOptionLabel("Print Invoice", false);
        Label dailyTotalOpt = makeOptionLabel("Get Daily Total", false);

        addSaleOpt.setOnMouseClicked(e -> {
            selectOptionLabel(addSaleOpt);
            showAddSalePopup();
            popup.hide();
        });

        viewSalesOpt.setOnMouseClicked(e -> {
            selectOptionLabel(viewSalesOpt);
            viewAllSales();
            popup.hide();
        });

        printInvoiceOpt.setOnMouseClicked(e -> {
            selectOptionLabel(printInvoiceOpt);
            showPrintInvoicePopup();
            popup.hide();
        });

        dailyTotalOpt.setOnMouseClicked(e -> {
            selectOptionLabel(dailyTotalOpt);
            showDailyTotalPopup();
            popup.hide();
        });

        optionBox.getChildren().addAll(addSaleOpt, viewSalesOpt, printInvoiceOpt, dailyTotalOpt);
        popup.getContent().add(optionBox);
    }

    public Popup getPopup() {
        return popup;
    }

    private Label makeOptionLabel(String text, boolean top) {
        Label lbl = new Label(text);
        lbl.setPrefWidth(160);
        lbl.setPadding(new Insets(10, 15, 10, 15));
        lbl.setFont(Font.font(14));
        lbl.setTextFill(Color.BLACK);

        String baseColor = "#ffc0cb"; // baby pink
        String hoverColor = "#ff1493"; // deep pink
        String radius = top ? "10 10 0 0" : "0 0 10 10";

        lbl.setStyle("-fx-background-color:" + baseColor + ";" +
                "-fx-border-color: transparent transparent #e68a99 transparent;" +
                "-fx-border-width: 0 0 1 0;" +
                "-fx-background-radius:" + radius + ";" +
                "-fx-font-weight: bold;");

        lbl.setOnMouseEntered(e -> {
            lbl.setStyle("-fx-background-color:" + hoverColor + ";" +
                    "-fx-border-color: transparent transparent #cc5c6f transparent;" +
                    "-fx-background-radius:" + radius + ";" +
                    "-fx-font-weight: bold;");
            lbl.setTextFill(Color.WHITE);
        });

        lbl.setOnMouseExited(e -> {
            lbl.setStyle("-fx-background-color:" + baseColor + ";" +
                    "-fx-border-color: transparent transparent #e68a99 transparent;" +
                    "-fx-background-radius:" + radius + ";" +
                    "-fx-font-weight: bold;");
            lbl.setTextFill(Color.BLACK);
        });

        return lbl;
    }

    private void selectOptionLabel(Label lbl) {
        if (selectedOptionLabel != null) {
            selectedOptionLabel.setTextFill(Color.BLACK);
        }
        selectedOptionLabel = lbl;
        selectedOptionLabel.setTextFill(Color.WHITE);
    }

    private void showAddSalePopup() {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.setTitle("Add New Sale");

        TextField customerField = new TextField();
        customerField.setPromptText("Customer Name");

        TextField productField = new TextField();
        productField.setPromptText("Product ID");

        Button addButton = new Button("Add Sale");

        Label feedback = new Label();
        feedback.setTextFill(Color.RED);

        addButton.setOnAction(e -> {
            String customerName = customerField.getText().trim();
            String productIdStr = productField.getText().trim();

            // Parse product ID as an integer
            int productId;
            try {
                productId = Integer.parseInt(productIdStr);
            } catch (NumberFormatException ex) {
                feedback.setText("Invalid Product ID! It must be a number.");
                return;
            }

            // Get the InventoryItem instead of Product
            InventoryItem item = salesManager.getProductById(productId);
            if (item != null) {
                List<InventoryItem> items = new ArrayList<>();
                items.add(item);
                salesManager.recordSale(items, customerName);
                feedback.setTextFill(Color.GREEN);
                feedback.setText("Sale added successfully!");
            } else {
                feedback.setText("Product not found.");
            }

            customerField.clear();
            productField.clear();
        });

        VBox layout = new VBox(10, customerField, productField, addButton, feedback);
        layout.setPadding(new Insets(15));
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: lightgreen;");
        layout.setPrefWidth(300);

        popupStage.setScene(new Scene(layout));
        popupStage.showAndWait();
    }

    private void viewAllSales() {
        StringBuilder salesList = new StringBuilder("Sales:\n");
        for (Sale sale : salesManager.getAllSales()) {
            salesList.append("Transaction ID: ").append(sale.getTransactionID())
                    .append(", Customer: ").append(sale.getCustomerName())
                    .append(", Total: ").append(sale.getTotalAmount())
                    .append(", Date: ").append(sale.getDate()).append("\n");
        }

        System.out.println(salesList.toString());
    }

    private void showPrintInvoicePopup() {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.setTitle("Print Invoice");

        TextField transactionIdField = new TextField();
        transactionIdField.setPromptText("Transaction ID");

        Button printButton = new Button("Print Invoice");

        Label feedback = new Label();
        feedback.setTextFill(Color.RED);

        printButton.setOnAction(e -> {
            String transactionIdStr = transactionIdField.getText().trim();
            try {
                int transactionId = Integer.parseInt(transactionIdStr);
                Sale sale = salesManager.getSaleById(transactionId);
                if (sale != null) {
                    sale.printInvoice();
                    feedback.setTextFill(Color.GREEN);
                    feedback.setText("Invoice printed successfully!");
                } else {
                    feedback.setText("Sale not found.");
                }
            } catch (NumberFormatException ex) {
                feedback.setText("Invalid Transaction ID! It must be a number.");
            }

            transactionIdField.clear();
        });

        VBox layout = new VBox(10, transactionIdField, printButton, feedback);
        layout.setPadding(new Insets(15));
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: lightgreen;");
        layout.setPrefWidth(300);

        popupStage.setScene(new Scene(layout));
        popupStage.showAndWait();
    }

    private void showDailyTotalPopup() {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.setTitle("Get Daily Total");

        TextField dateField = new TextField();
        dateField.setPromptText("Enter date (YYYY-MM-DD)");

        Button totalButton = new Button("Get Total");

        Label feedback = new Label();
        feedback.setTextFill(Color.RED);

        totalButton.setOnAction(e -> {
            String date = dateField.getText().trim();
            double total = salesManager.getDailyTotal(date);
            feedback.setTextFill(Color.GREEN);
            feedback.setText("Total sales for " + date + ": " + total);
            dateField.clear();
        });

        VBox layout = new VBox(10, dateField, totalButton, feedback);
        layout.setPadding(new Insets(15));
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: lightgreen;");
        layout.setPrefWidth(300);

        popupStage.setScene(new Scene(layout));
        popupStage.showAndWait();
    }
}
