package ClothingStore.Member3_Sales_And_Billing;

import ClothingStore.Member2_Inventory_Management.InventoryItem;
import java.util.List;

public class Sale extends Transaction {
    private List<InventoryItem> items;
    private String customerName;

    public Sale(int transactionID, double totalAmount, String date, List<InventoryItem> items, String customerName) {
        super(transactionID, totalAmount, date);
        this.items = items;
        this.customerName = customerName;
    }

    public List<InventoryItem> getItems() {
        return items;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void addItem(InventoryItem item) {
        this.items.add(item);
    }

    @Override
    public void printInvoice() {
        System.out.println("Customer: " + customerName);
        for (InventoryItem item : items) {
            System.out.println(item.getName() + " - " + item.getPrice());
        }
        System.out.println("Total: " + totalAmount);
        System.out.println("Date: " + date);
    }

    @Override
    public String getDate() {
        return date;
    }

    @Override
    public double getTotalAmount() {
        return totalAmount;
    }

    @Override
    public int getTransactionID() {
        return transactionID;
    }
}
