


package ClothingStore;

import ClothingStore.Member1_Product_Management.Member1UI;
import ClothingStore.Member3_Sales_And_Billing.Member3UI;
import ClothingStore.Member4_Employee_Management.Member4UI;
import ClothingStore.Member5_Reports_And_Feedback.Member5UI;
import ClothingStore.Member2_Inventory_Management.Member2UI;
import ClothingStore.Member4_Employee_Management.EmployeeManager;
import ClothingStore.Member2_Inventory_Management.InventoryManager;
import ClothingStore.Member3_Sales_And_Billing.SalesManager;
import ClothingStore.Member5_Reports_And_Feedback.FeedbackManager;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Popup;
import javafx.stage.Stage;

public class UIFrontend extends Application {

    private Member5UI member5UI;
    private Member4UI member4UI;
    private Member1UI member1UI;
    private Member2UI member2UI;
    private Member3UI member3UI;

    private InventoryManager inventoryManager;
    private SalesManager salesManager;
    private FeedbackManager feedbackManager;

    private Popup currentPopup = null;
    private Button activeButton = null;

    private Button productBtn;
    private Button member2Btn;
    private Button member3Btn;
    private Button member4Btn;
    private Button member5Btn;

    private BorderPane root;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
      
        feedbackManager = new FeedbackManager();
        inventoryManager = new InventoryManager();
        salesManager = new SalesManager(inventoryManager);
        
        // Initialize UIs
        member5UI = new Member5UI(feedbackManager);
        member4UI = new Member4UI(new EmployeeManager());
        member2UI = new Member2UI(inventoryManager);
        member3UI = new Member3UI(salesManager);
        member1UI = new Member1UI();

        root = new BorderPane();
        root.setStyle("-fx-background-color: honeydew;");

        Rectangle bgRect = new Rectangle();
        bgRect.setFill(Color.LIGHTGREY);
        bgRect.setHeight(70);
        bgRect.widthProperty().bind(stage.widthProperty());

        Label titleLabel = new Label(" 𝓣𝓱𝓻𝓮𝓪𝓭𝓼 & 𝓣𝓪𝓵𝓮𝓼 ");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 38));
        titleLabel.setTextFill(Color.web("#FF1493"));

        StackPane titlePane = new StackPane(bgRect, titleLabel);
        titlePane.setAlignment(Pos.CENTER_LEFT);
        titlePane.setPadding(new Insets(0, 0, 0, 15));
        root.setTop(titlePane);

        VBox sideBar = new VBox(10);
        sideBar.setPadding(new Insets(20));
        sideBar.setStyle("-fx-background-color: mistyrose;");
        sideBar.setPrefWidth(200);
        sideBar.setAlignment(Pos.TOP_CENTER);

        productBtn = makeSideButton("Product", 180, 60);
        member2Btn = makeSideButton("Inventory", 180, 60);
        member3Btn = makeSideButton("Sales & Billing", 180, 60);
        member4Btn = makeSideButton("Employees", 180, 60);
        member5Btn = makeSideButton("Feedback", 180, 60);

        sideBar.getChildren().addAll(productBtn, member2Btn, member3Btn, member4Btn, member5Btn);
        root.setLeft(sideBar);

        Label welcome = new Label("𝐻𝑒𝓇𝑒 𝐸𝓋𝑒𝓇𝓎 𝒮𝓉𝒾𝓉𝒸𝒽 𝒯𝑒𝓁𝓁𝓈 𝒶 𝒮𝓉𝑜𝓇𝓎");
        welcome.setFont(Font.font("Verdana", FontWeight.NORMAL, 24));
        welcome.setTextFill(Color.DARKGREEN);
        StackPane centerPane = new StackPane(welcome);
        root.setCenter(centerPane);

        productBtn.setOnAction(e -> handlePopup(productBtn, member1UI.getPopup()));
        member2Btn.setOnAction(e -> handlePopup(member2Btn, member2UI.getPopup()));
        member3Btn.setOnAction(e -> handlePopup(member3Btn, member3UI.getPopup()));
        member4Btn.setOnAction(e -> handlePopup(member4Btn, member4UI.getPopup()));
        member5Btn.setOnAction(e -> handlePopup(member5Btn, member5UI.getPopup()));

        root.addEventFilter(MouseEvent.MOUSE_PRESSED, event -> {
            if (currentPopup != null && currentPopup.isShowing()) {
                boolean insideBtn = activeButton != null && activeButton.localToScreen(activeButton.getBoundsInLocal())
                        .contains(event.getScreenX(), event.getScreenY());
                boolean insidePopup = currentPopup.getContent().stream().anyMatch(node ->
                        node.localToScreen(node.getBoundsInLocal())
                                .contains(event.getScreenX(), event.getScreenY()));
                if (!insideBtn && !insidePopup) {
                    hideCurrentPopup();
                    setActiveButton(null);
                }
            }
        });

        Scene scene = new Scene(root, 900, 600);
        stage.setScene(scene);
        stage.setTitle("𝕿𝖍𝖗𝖊𝖆𝖉𝖘 𝕬𝖓𝖉 𝕿𝖆𝖑𝖊𝖘");
        stage.show();
    }

    private void handlePopup(Button sourceBtn, Popup popup) {
        if (currentPopup != null && currentPopup.isShowing()) {
            hideCurrentPopup();
            if (activeButton == sourceBtn) {
                setActiveButton(null);
                return;
            }
        }

        setActiveButton(sourceBtn);

        // Show the popup at screen coordinates next to the button
        double btnX = sourceBtn.localToScreen(sourceBtn.getBoundsInLocal()).getMinX();
        double btnY = sourceBtn.localToScreen(sourceBtn.getBoundsInLocal()).getMinY();

        popup.show(sourceBtn.getScene().getWindow(),
                btnX + sourceBtn.getWidth() + 5,
                btnY);

        currentPopup = popup;
    }

    private Button makeSideButton(String text, double width, double height) {
        Button btn = new Button(text);
        btn.setPrefSize(width, height);
        btn.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        btn.setStyle("-fx-background-color: #c8e6c9; " +
                "-fx-border-radius: 20; -fx-background-radius: 20; " +
                "-fx-border-color: transparent; " +
                "-fx-font-weight: bold; " +
                "-fx-text-fill: #3e4c3a;");
        return btn;
    }

    private void hideCurrentPopup() {
        if (currentPopup != null) {
            currentPopup.hide();
            currentPopup = null;
        }
    }

    private void setActiveButton(Button btn) {
        if (activeButton != null && activeButton != btn) {
            activeButton.setStyle("-fx-background-color: #c8e6c9; " +
                    "-fx-border-radius: 20; -fx-background-radius: 20; " +
                    "-fx-border-color: transparent; " +
                    "-fx-font-weight: bold; " +
                    "-fx-text-fill: #3e4c3a;");
        }
        if (btn != null) {
            btn.setStyle("-fx-background-color: #8bc34a; " +
                    "-fx-border-radius: 20; -fx-background-radius: 20; " +
                    "-fx-border-color: mediumseagreen; " +
                    "-fx-border-width: 3; " +
                    "-fx-font-weight: bold; " +
                    "-fx-text-fill: white;");
        }
        activeButton = btn;
    }
}



