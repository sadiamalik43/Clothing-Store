package ClothingStore.Member5_Reports_And_Feedback;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class Member5UI {

    private VBox optionBox;
    private Label selectedOptionLabel = null;
    private Popup popup;
    private FeedbackManager feedbackManager;

    public Member5UI(FeedbackManager feedbackManager) {
        this.feedbackManager = feedbackManager;
        popup = new Popup();
        popup.setAutoHide(true);
        buildPopup();
    }

    private void buildPopup() {
        optionBox = new VBox();
        optionBox.setAlignment(Pos.TOP_LEFT);
        optionBox.setPadding(new Insets(0, 5, 5, 5));
        optionBox.setSpacing(0);

        Label submitFeedbackOpt = makeOptionLabel("Submit Feedback", true);
        Label viewAllFeedbackOpt = makeOptionLabel("View All Feedback", false);
        Label viewPendingFeedbackOpt = makeOptionLabel("View Pending Feedback", false);
        Label filterFeedbackOpt = makeOptionLabel("Filter Feedback", false);

        submitFeedbackOpt.setOnMouseClicked(e -> {
            selectOptionLabel(submitFeedbackOpt);
            showSubmitFeedbackPopup();
            popup.hide();
        });

        viewAllFeedbackOpt.setOnMouseClicked(e -> {
            selectOptionLabel(viewAllFeedbackOpt);
            viewAllFeedback();
            popup.hide();
        });

        viewPendingFeedbackOpt.setOnMouseClicked(e -> {
            selectOptionLabel(viewPendingFeedbackOpt);
            viewPendingFeedback();
            popup.hide();
        });

        filterFeedbackOpt.setOnMouseClicked(e -> {
            selectOptionLabel(filterFeedbackOpt);
            showFilterFeedbackDialog();
            popup.hide();
        });

        optionBox.getChildren().addAll(submitFeedbackOpt, viewAllFeedbackOpt, viewPendingFeedbackOpt, filterFeedbackOpt);
        popup.getContent().add(optionBox);
    }

    public Popup getPopup() {
        return popup;
    }

    public VBox getView() {
        VBox mainView = new VBox(10);
        mainView.setPadding(new Insets(15));
        mainView.setAlignment(Pos.TOP_LEFT);
        mainView.setStyle("-fx-background-color: lightyellow;");

        Label titleLabel = new Label("Feedback Management");
        titleLabel.setFont(Font.font(20));
        titleLabel.setTextFill(Color.DARKBLUE);

        Button feedbackButton = new Button("Manage Feedback");
        feedbackButton.setOnAction(e -> {
            popup.show(feedbackButton.getScene().getWindow(),
                    feedbackButton.getLayoutX(),
                    feedbackButton.getLayoutY() + feedbackButton.getHeight());
        });

        mainView.getChildren().addAll(titleLabel, feedbackButton);
        return mainView;
    }

    private Label makeOptionLabel(String text, boolean top) {
        Label lbl = new Label(text);
        lbl.setPrefWidth(160);
        lbl.setPadding(new Insets(10, 15, 10, 15));
        lbl.setFont(Font.font(14));
        lbl.setTextFill(Color.BLACK);

        String baseColor = "#ffc0cb"; // baby pink
        String hoverColor = "#ff1493"; // deep pink
        String radius = top ? "10 10 0 0" : "0 0 10 10";

        lbl.setStyle("-fx-background-color:" + baseColor + ";" +
                "-fx-border-color: transparent transparent #e68a99 transparent;" +
                "-fx-border-width: 0 0 1 0;" +
                "-fx-background-radius:" + radius + ";" +
                "-fx-font-weight: bold;");

        lbl.setOnMouseEntered(e -> {
            lbl.setStyle("-fx-background-color:" + hoverColor + ";" +
                    "-fx-border-color: transparent transparent #cc5c6f transparent;" +
                    "-fx-background-radius:" + radius + ";" +
                    "-fx-font-weight: bold;");
            lbl.setTextFill(Color.WHITE);
        });

        lbl.setOnMouseExited(e -> {
            lbl.setStyle("-fx-background-color:" + baseColor + ";" +
                    "-fx-border-color: transparent transparent #e68a99 transparent;" +
                    "-fx-border-width: 0 0 1 0;" +
                    "-fx-background-radius:" + radius + ";" +
                    "-fx-font-weight: bold;");
            lbl.setTextFill(Color.BLACK);
        });

        return lbl;
    }

    private void selectOptionLabel(Label lbl) {
        if (selectedOptionLabel != null) {
            selectedOptionLabel.setTextFill(Color.BLACK);
        }
        selectedOptionLabel = lbl;
        selectedOptionLabel.setTextFill(Color.WHITE);
    }

    private void showSubmitFeedbackPopup() {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.setTitle("Submit Feedback");

        TextField ratingField = new TextField();
        ratingField.setPromptText("Enter rating (1-5)");

        TextField typeField = new TextField();
        typeField.setPromptText("Feedback type (Complaint/Suggestion/Praise)");

        TextArea commentsArea = new TextArea();
        commentsArea.setPromptText("Enter your comments");
        commentsArea.setWrapText(true);

        Button submitButton = new Button("Submit");
        Label feedbackLabel = new Label();
        feedbackLabel.setTextFill(Color.RED);

        submitButton.setOnAction(e -> {
            try {
                int rating = Integer.parseInt(ratingField.getText().trim());
                if (rating < 1 || rating > 5) {
                    feedbackLabel.setText("Rating must be between 1 and 5.");
                    return;
                }
                String type = typeField.getText().trim();
                String comments = commentsArea.getText().trim();

                if (type.isEmpty() || comments.isEmpty()) {
                    feedbackLabel.setText("Please fill in all fields.");
                    return;
                }

                FeedbackManager.Feedback feedback = new FeedbackManager.Feedback(
                        "FB-" + System.currentTimeMillis(),
                        rating,
                        comments,
                        type
                );
                feedback.setEmployeeName("Anonymous");

                feedbackManager.addFeedback(feedback);

                feedbackLabel.setTextFill(Color.GREEN);
                feedbackLabel.setText("Feedback submitted successfully!");

                // Clear fields after submission
                ratingField.clear();
                typeField.clear();
                commentsArea.clear();
            } catch (NumberFormatException ex) {
                feedbackLabel.setText("Invalid rating. Please enter an integer between 1 and 5.");
            }
        });

        VBox layout = new VBox(10, ratingField, typeField, commentsArea, submitButton, feedbackLabel);
        layout.setPadding(new Insets(15));
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: lightgreen;");
        layout.setPrefWidth(300);

        popupStage.setScene(new Scene(layout));
        popupStage.showAndWait();
    }

    private void viewAllFeedback() {
        StringBuilder feedbackList = new StringBuilder("Feedback:\n");
        for (FeedbackManager.Feedback feedback : feedbackManager.getAllFeedback()) {
            feedbackList.append("ID: ").append(feedback.getFeedbackId())
                    .append(", Type: ").append(feedback.getFeedbackType())
                    .append(", Rating: ").append(feedback.getRating())
                    .append(", Comments: ").append(feedback.getComments()).append("\n");
        }
        showAlert("All Feedback", feedbackList.toString());
    }

    private void viewPendingFeedback() {
        StringBuilder pendingFeedbackList = new StringBuilder("Pending Feedback:\n");
        for (FeedbackManager.Feedback feedback : feedbackManager.getFeedbackRequiringFollowUp()) {
            pendingFeedbackList.append("ID: ").append(feedback.getFeedbackId())
                    .append(", Type: ").append(feedback.getFeedbackType())
                    .append(", Rating: ").append(feedback.getRating())
                    .append(", Comments: ").append(feedback.getComments()).append("\n");
        }
        showAlert("Pending Feedback", pendingFeedbackList.toString());
    }

    private void showFilterFeedbackDialog() {
        Stage filterStage = new Stage();
        filterStage.initModality(Modality.APPLICATION_MODAL);
        filterStage.setTitle("Filter Feedback");

        TextField minRatingField = new TextField();
        minRatingField.setPromptText("Enter minimum rating (1-5)");

        Button filterButton = new Button("Filter");
        Label filterFeedbackLabel = new Label();
        filterFeedbackLabel.setTextFill(Color.RED);

        filterButton.setOnAction(e -> {
            try {
                int minRating = Integer.parseInt(minRatingField.getText().trim());
                if (minRating < 1 || minRating > 5) {
                    filterFeedbackLabel.setText("Minimum rating must be between 1 and 5.");
                    return;
                }

                StringBuilder filteredFeedbackList = new StringBuilder("Filtered Feedback:\n");
                for (FeedbackManager.Feedback feedback : feedbackManager.getAllFeedback()) {
                    if (feedback.getRating() >= minRating) {
                        filteredFeedbackList.append("ID: ").append(feedback.getFeedbackId())
                                .append(", Type: ").append(feedback.getFeedbackType())
                                .append(", Rating: ").append(feedback.getRating())
                                .append(", Comments: ").append(feedback.getComments()).append("\n");
                    }
                }

                showAlert("Filtered Feedback", filteredFeedbackList.toString());
                filterStage.close();
            } catch (NumberFormatException ex) {
                filterFeedbackLabel.setText("Invalid rating. Please enter an integer between 1 and 5.");
            }
        });

        VBox layout = new VBox(10, minRatingField, filterButton, filterFeedbackLabel);
        layout.setPadding(new Insets(15));
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: lightyellow;");
        layout.setPrefWidth(300);

        filterStage.setScene(new Scene(layout));
        filterStage.showAndWait();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

