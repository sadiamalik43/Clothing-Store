package ClothingStore.Member5_Reports_And_Feedback;
import ClothingStore.Member2_Inventory_Management.InventoryManager;
import ClothingStore.Member4_Employee_Management.Employee;
import ClothingStore.Member2_Inventory_Management.InventoryItem;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ReportManager {

    public Report generateInventoryReport(List<InventoryItem> inventoryItems) {
        Report report = new Report(
                "INV-RPT-" + System.currentTimeMillis(),
                "Inventory",
                LocalDate.now(),
                LocalDate.now()
        );

        List<ReportItem> reportItems = new ArrayList<>();
        for (InventoryItem item : inventoryItems) {
            reportItems.add(new ReportItem(
                    String.valueOf(item.getId()),
                    item.getName(),
                    item.getCategory().toString(),
                    item.getQuantity(),
                    item.getPrice()
            ));
        }

        report.setItems(reportItems);
        report.calculateTotals();
        return report;
    }

    public Report generateSalesReport(LocalDate startDate, LocalDate endDate, List<?> sales) {
        Report report = new Report(
                "RPT-" + System.currentTimeMillis(),
                "Sales",
                startDate,
                endDate
        );

        report.setItems(new ArrayList<>());
        report.calculateTotals();
        return report;
    }

    public Report generateEmployeePerformanceReport(List<Employee> employees, List<?> sales) {
        Report report = new Report(
                "EMP-RPT-" + System.currentTimeMillis(),
                "Employee Performance",
                LocalDate.now().minusMonths(1),
                LocalDate.now()
        );

        report.setItems(new ArrayList<>());
        report.calculateTotals();
        return report;
    }

    // Report class
    public static class Report {
        private String reportId;
        private String reportType;
        private LocalDate startDate;
        private LocalDate endDate;
        private List<ReportItem> items;
        private double totalSales;
        private int totalItemsSold;

        public Report(String reportId, String reportType, LocalDate startDate, LocalDate endDate) {
            this.reportId = reportId;
            this.reportType = reportType;
            this.startDate = startDate;
            this.endDate = endDate;
        }

        public String getReportId() { return reportId; }
        public String getReportType() { return reportType; }
        public LocalDate getStartDate() { return startDate; }
        public LocalDate getEndDate() { return endDate; }
        public List<ReportItem> getItems() { return items; }
        public void setItems(List<ReportItem> items) { this.items = items; }
        public double getTotalSales() { return totalSales; }
        public void setTotalSales(double totalSales) { this.totalSales = totalSales; }
        public int getTotalItemsSold() { return totalItemsSold; }
        public void setTotalItemsSold(int totalItemsSold) { this.totalItemsSold = totalItemsSold; }

        public void calculateTotals() {
            if (items != null) {
                totalSales = items.stream().mapToDouble(ReportItem::getItemTotal).sum();
                totalItemsSold = items.stream().mapToInt(ReportItem::getQuantity).sum();
            }
        }
    }

    // ReportItem class
    public static class ReportItem {
        private String productId;
        private String productName;
        private String category;
        private int quantity;
        private double unitPrice;
        private double itemTotal;

        public ReportItem(String productId, String productName, String category, int quantity, double unitPrice) {
            this.productId = productId;
            this.productName = productName;
            this.category = category;
            this.quantity = quantity;
            this.unitPrice = unitPrice;
            this.itemTotal = quantity * unitPrice;
        }

        public String getProductId() { return productId; }
        public String getProductName() { return productName; }
        public String getCategory() { return category; }
        public int getQuantity() { return quantity; }
        public double getUnitPrice() { return unitPrice; }
        public double getItemTotal() { return itemTotal; }
    }
}
