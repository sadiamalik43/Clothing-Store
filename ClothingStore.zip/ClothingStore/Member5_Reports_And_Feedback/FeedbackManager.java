package ClothingStore.Member5_Reports_And_Feedback;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FeedbackManager {

    private List<Feedback> feedbackList;

    public FeedbackManager() {
        this.feedbackList = new ArrayList<>();
    }

    public void addFeedback(Feedback feedback) {
        feedbackList.add(feedback);
    }

    public List<Feedback> getAllFeedback() {
        return new ArrayList<>(feedbackList);
    }

    public List<Feedback> getFeedbackRequiringFollowUp() {
        return feedbackList.stream()
                .filter(Feedback::isFollowUpRequired)
                .collect(Collectors.toList());
    }

    public List<Feedback> getFeedbackByRating(int minRating) {
        return feedbackList.stream()
                .filter(f -> f.getRating() >= minRating)
                .collect(Collectors.toList());
    }

    public double getAverageRating() {
        return feedbackList.stream()
                .mapToInt(Feedback::getRating)
                .average()
                .orElse(0.0);
    }

    public void markAsResolved(String feedbackId) {
        feedbackList.stream()
                .filter(f -> f.getFeedbackId().equals(feedbackId))
                .findFirst()
                .ifPresent(f -> f.setFollowUpRequired(false));
    }

    public static class Feedback {
        private String feedbackId;
        private String employeeName;
        private int rating;
        private String comments;
        private LocalDateTime submissionDate;
        private String feedbackType;
        private boolean followUpRequired;
        private String emoji;

        public Feedback(String feedbackId, int rating, String comments, String feedbackType) {
            this.feedbackId = feedbackId;
            this.rating = rating;
            this.comments = comments;
            this.feedbackType = feedbackType;
            this.submissionDate = LocalDateTime.now();
            this.followUpRequired = rating < 3;
            this.emoji = calculateEmoji();
        }

        public String calculateEmoji() {
            return switch (rating) {
                case 5 -> "😍";
                case 4 -> "😊";
                case 3 -> "😐";
                case 2 -> "😞";
                case 1 -> "😠";
                default -> "❓";
            };
        }

        public String getThankYouMessage() {
            if (rating >= 4) {
                return "🌟 Thank you for your positive feedback! 🌟";
            } else if (rating == 3) {
                return "✓ Feedback received. We'll improve!";
            } else {
                return "⚠️ We apologize and will address this.";
            }
        }

        
        public String getFeedbackId() { return feedbackId; }
        public String getEmployeeName() { return employeeName; }
        public void setEmployeeName(String employeeName) { this.employeeName = employeeName; }
        public int getRating() { return rating; }
        public String getComments() { return comments; }
        public LocalDateTime getSubmissionDate() { return submissionDate; }
        public String getFeedbackType() { return feedbackType; }
        public boolean isFollowUpRequired() { return followUpRequired; }
        public void setFollowUpRequired(boolean followUpRequired) { this.followUpRequired = followUpRequired; }
        public String getEmoji() { return emoji; }
    }
}
