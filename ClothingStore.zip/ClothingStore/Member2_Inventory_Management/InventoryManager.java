package ClothingStore.Member2_Inventory_Management;

import ClothingStore.Member1_Product_Management.Category;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;

public class InventoryManager {
    private List<InventoryItem> items;

    public InventoryManager() {
        items = new ArrayList<>();

        // Preexisting inventory items with int IDs
        items.add(new InventoryItem(1, "Black T-Shirt", Category.MEN, 799.99, 25, 10));
        items.add(new InventoryItem(2, "Blue Jeans", Category.WOMEN, 1299.50, 15, 5));
        items.add(new InventoryItem(3, "Kids Sneakers", Category.KIDS, 999.00, 8, 3));
        items.add(new InventoryItem(4, "Formal Shirt", Category.MEN, 1499.00, 5, 2));
        items.add(new InventoryItem(5, "Red Hoodie", Category.MEN, 1599.99, 6, 8));
        items.add(new InventoryItem(6, "Summer Dress", Category.WOMEN, 1799.00, 18, 7));
        items.add(new InventoryItem(7, "Running Shoes", Category.KIDS, 1299.50, 3, 5));
        items.add(new InventoryItem(8, "Leather Jacket", Category.MEN, 4999.00, 2, 3));
        items.add(new InventoryItem(9, "White Blouse", Category.WOMEN, 999.99, 22, 10));
        items.add(new InventoryItem(10, "Baseball Cap", Category.MEN, 499.00, 30, 15));
        items.add(new InventoryItem(11, "Denim Skirt", Category.WOMEN, 1099.50, 5, 6));
        items.add(new InventoryItem(12, "Sandals", Category.KIDS, 799.00, 16, 6));
        items.add(new InventoryItem(13, "Wool Sweater", Category.MEN, 2499.99, 3, 4));
        items.add(new InventoryItem(14, "Floral Scarf", Category.WOMEN, 599.00, 19, 8));
        items.add(new InventoryItem(15, "Kids Jacket", Category.KIDS, 1699.00, 2, 3));
        items.add(new InventoryItem(16, "Graphic Tee", Category.MEN, 699.99, 24, 10));
        items.add(new InventoryItem(17, "Pleated Pants", Category.WOMEN, 1399.50, 13, 5));
        items.add(new InventoryItem(18, "Sneakers", Category.KIDS, 1199.00, 10, 4));
        items.add(new InventoryItem(19, "Raincoat", Category.MEN, 2999.00, 1, 3));
        items.add(new InventoryItem(20, "Leather Belt", Category.WOMEN, 799.00, 21, 9));
        items.add(new InventoryItem(21, "Beanie Hat", Category.KIDS, 399.00, 25, 10));
        items.add(new InventoryItem(22, "Sports Shorts", Category.MEN, 899.99, 23, 9));
        items.add(new InventoryItem(23, "Maxi Dress", Category.WOMEN, 1999.00, 17, 6));
        items.add(new InventoryItem(24, "Flip Flops", Category.KIDS, 499.00, 7, 7));
    }

    public List<InventoryItem> getItems() {
        return items;
    }

    public void viewItems() {
        if (items.isEmpty()) {
            System.out.println("No inventory items to show.");
        } else {
            for (InventoryItem item : items) {
                item.display(); // Assuming display() method is defined in InventoryItem
            }
        }
    }

    // Search by int id
    public InventoryItem searchById(int id) {
        for (InventoryItem item : items) {
            if (item.getId() == id) {
                return item;
            }
        }
        return null;
    }

    public void updateStock(int id, int newQuantity) {
        InventoryItem item = searchById(id);
        if (item != null) {
            item.setQuantity(newQuantity);
            System.out.println("Stock updated.");
        } else {
            System.out.println("Item not found.");
        }
    }

    public void viewLowStockItems() {
        System.out.println("⚠️ Low Stock Items:");
        boolean found = false;
        for (InventoryItem item : items) {
            if (!item.isDiscontinued() && item.isLowStock()) {
                item.display();
                found = true;
            }
        }
        if (!found) {
            System.out.println("All items are sufficiently stocked.");
        }
    }

    public void restockItem(int id, int amount) {
        InventoryItem item = searchById(id);
        if (item != null) {
            item.restock(amount);
            System.out.println("Item restocked.");
        } else {
            System.out.println("Item not found.");
        }
    }

    public void sortByQuantity(boolean ascending) {
        if (ascending) {
            items.sort(Comparator.comparingInt(InventoryItem::getQuantity));
        } else {
            items.sort(Comparator.comparingInt(InventoryItem::getQuantity).reversed());
        }
    }

    public void sortByPrice(boolean ascending) {
        if (ascending) {
            items.sort(Comparator.comparingDouble(InventoryItem::getPrice));
        } else {
            items.sort(Comparator.comparingDouble(InventoryItem::getPrice).reversed());
        }
    }

    public double getTotalInventoryValue() {
        double total = 0;
        for (InventoryItem item : items) {
            if (!item.isDiscontinued()) {
                total += item.getPrice() * item.getQuantity();
            }
        }
        return total;
    }

    public void markItemAsDiscontinued(int id) {
        InventoryItem item = searchById(id);
        if (item != null) {
            item.setDiscontinued(true);
            System.out.println("Item " + id + " marked as discontinued.");
        } else {
            System.out.println("Product not found.");
        }
    }

    public void generateInventoryReport() {
        System.out.println("\n===== Inventory Report =====");
        System.out.printf("%-10s %-20s %-10s %-8s %-10s %-15s\n",
                "ProductID", "Name", "Category", "Price", "Quantity", "Low Stock?");
        System.out.println("------------------------------------------------------------------");

        for (InventoryItem item : items) {
            String lowStock = item.isLowStock() ? "Yes" : "No";
            System.out.printf("%-10d %-20s %-10s %-8.2f %-10d %-15s\n",
                    item.getId(), item.getName(), item.getCategory(),
                    item.getPrice(), item.getQuantity(), lowStock);
        }
    }

    public void exportInventoryToCSV(String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            writer.write("ProductID,Name,Category,Price,Quantity,ReorderThreshold,LowStock,Discontinued\n");

            for (InventoryItem item : items) {
                writer.write(item.getId() + "," +
                        item.getName() + "," +
                        item.getCategory() + "," +
                        item.getPrice() + "," +
                        item.getQuantity() + "," +
                        item.getReorderThreshold() + "," +
                        item.isLowStock() + "," +
                        item.isDiscontinued() + "\n");
            }

            System.out.println("✅ Inventory exported to file: " + filename);
        } catch (IOException e) {
            System.out.println("❌ Error exporting inventory: " + e.getMessage());
        }
    }
}
