package ClothingStore.Member2_Inventory_Management;

import java.util.Scanner;

public class Main2 {

    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== Inventory Management Menu =====");
            System.out.println("1. View Inventory");
            System.out.println("2. Update Stock");
            System.out.println("3. View Low Stock Items");
            System.out.println("4. Restock Item");
            System.out.println("5. Sort by Quantity");
            System.out.println("6. Sort by Price");
            System.out.println("7. View Total Inventory Value");
            System.out.println("8. Mark Item as Discontinued");
            System.out.println("9. Generate Inventory Report");
            System.out.println("10. Export Inventory to CSV");
            System.out.println("11. Exit");
            System.out.print("Choose an option: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    manager.viewItems();
                    break;
                case "2":
                    updateStock(manager, scanner);
                    break;
                case "3":
                    manager.viewLowStockItems();
                    break;
                case "4":
                    restockItem(manager, scanner);
                    break;
                case "5":
                    sortByQuantity(manager, scanner);
                    break;
                case "6":
                    sortByPrice(manager, scanner);
                    break;
                case "7":
                    System.out.printf("Total inventory value: %.2f\n", manager.getTotalInventoryValue());
                    break;
                case "8":
                    markAsDiscontinued(manager, scanner);
                    break;
                case "9":
                    manager.generateInventoryReport();
                    break;
                case "10":
                    System.out.print("Enter filename to export (e.g., inventory.csv): ");
                    String filename = scanner.nextLine();
                    manager.exportInventoryToCSV(filename);
                    break;
                case "11":
                    System.out.println("Exiting program. Goodbye!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }

    private static void updateStock(InventoryManager manager, Scanner scanner) {
        System.out.print("Enter Product ID to update stock: ");
        String updateIdStr = scanner.nextLine();

        int updateId;
        try {
            updateId = Integer.parseInt(updateIdStr);
        } catch (NumberFormatException e) {
            System.out.println("Invalid Product ID! It must be a number.");
            return;
        }

        System.out.print("Enter new quantity: ");
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input! Quantity must be a number.");
            System.out.print("Enter new quantity: ");
            scanner.next();
        }
        int newQty = scanner.nextInt();
        scanner.nextLine();

        manager.updateStock(updateId, newQty);
    }

    private static void restockItem(InventoryManager manager, Scanner scanner) {
        System.out.print("Enter Product ID to restock: ");
        String restockIdStr = scanner.nextLine();

        int restockId;
        try {
            restockId = Integer.parseInt(restockIdStr);
        } catch (NumberFormatException e) {
            System.out.println("Invalid Product ID! It must be a number.");
            return;
        }

        System.out.print("Enter amount to add: ");
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input! Amount must be a number.");
            System.out.print("Enter amount to add: ");
            scanner.next();
        }
        int restockAmount = scanner.nextInt();
        scanner.nextLine();

        manager.restockItem(restockId, restockAmount);
    }

    private static void sortByQuantity(InventoryManager manager, Scanner scanner) {
        System.out.print("Sort by quantity ascending? (yes/no): ");
        String input = scanner.nextLine().trim().toLowerCase();
        boolean ascending = input.equals("yes") || input.equals("y");
        manager.sortByQuantity(ascending);
        System.out.println("Items sorted by quantity " + (ascending ? "ascending." : "descending."));
    }

    private static void sortByPrice(InventoryManager manager, Scanner scanner) {
        System.out.print("Sort by price ascending? (yes/no): ");
        String input = scanner.nextLine().trim().toLowerCase();
        boolean ascending = input.equals("yes") || input.equals("y");
        manager.sortByPrice(ascending);
        System.out.println("Items sorted by price " + (ascending ? "ascending." : "descending."));
    }

    private static void markAsDiscontinued(InventoryManager manager, Scanner scanner) {
        System.out.print("Enter Product ID to mark as discontinued: ");
        String discontinueIdStr = scanner.nextLine();

        int discontinueId;
        try {
            discontinueId = Integer.parseInt(discontinueIdStr);
        } catch (NumberFormatException e) {
            System.out.println("Invalid Product ID! It must be a number.");
            return;
        }

        manager.markItemAsDiscontinued(discontinueId);
    }
}
