package ClothingStore.Member2_Inventory_Management;

import ClothingStore.Member1_Product_Management.Category;
import ClothingStore.Member1_Product_Management.Product;

public class InventoryItem extends Product {
    private int quantity;
    private int reorderThreshold;
    private boolean discontinued;

    public InventoryItem(int id, String name, Category category, double price, int quantity, int reorderThreshold) {
        super(id, name, price, category);
        this.quantity = quantity;
        this.reorderThreshold = reorderThreshold;
        this.discontinued = false;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getReorderThreshold() {
        return reorderThreshold;
    }

    public void setReorderThreshold(int reorderThreshold) {
        this.reorderThreshold = reorderThreshold;
    }

    public boolean isDiscontinued() {
        return discontinued;
    }

    public void setDiscontinued(boolean discontinued) {
        this.discontinued = discontinued;
    }

    public boolean isLowStock() {
        return quantity <= reorderThreshold;
    }

    public void restock(int amount) {
        if (amount > 0) {
            quantity += amount;
        }
    }

    public void display() {
        System.out.println("Product ID: " + getId());
        System.out.println("Name: " + getName());
        System.out.println("Category: " + getCategory());
        System.out.println("Price: $" + getPrice());
        System.out.println("Quantity: " + quantity);
        System.out.println("Reorder Threshold: " + reorderThreshold);
        System.out.println("Discontinued: " + (discontinued ? "Yes" : "No"));
    }
}
