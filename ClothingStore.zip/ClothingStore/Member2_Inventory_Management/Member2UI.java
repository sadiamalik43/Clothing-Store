package ClothingStore.Member2_Inventory_Management;

import ClothingStore.Member1_Product_Management.Product;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.beans.property.SimpleStringProperty;

public class Member2UI {

    private InventoryManager inventoryManager;
    private TableView<InventoryItem> table;
    private ObservableList<InventoryItem> data;
    private VBox optionBox;
    private Label selectedOptionLabel = null;
    private Popup popup;

    public Member2UI(InventoryManager inventoryManager) {
        this.inventoryManager = inventoryManager;
        this.popup = new Popup();
        this.popup.setAutoHide(true);
        buildPopup();
        setupTable();
    }

    private void buildPopup() {
        optionBox = new VBox();
        optionBox.setAlignment(Pos.TOP_LEFT);
        optionBox.setPadding(new Insets(10));
        optionBox.setSpacing(0);

        Label restockOpt = makeOptionLabel("Restock Item", true);
        Label searchOpt = makeOptionLabel("Search Product", false);
        Label exportOpt = makeOptionLabel("Export to CSV", false);
        Label sortAscOpt = makeOptionLabel("Sort by Price Asc", false);
        Label sortDescOpt = makeOptionLabel("Sort by Price Desc", false);

        restockOpt.setOnMouseClicked(e -> {
            selectOptionLabel(restockOpt);
            showRestockPopup();
        });

        searchOpt.setOnMouseClicked(e -> {
            selectOptionLabel(searchOpt);
            showSearchPopup();
        });

        exportOpt.setOnMouseClicked(e -> {
            selectOptionLabel(exportOpt);
            inventoryManager.exportInventoryToCSV("inventory_export.csv");
            showMessagePopup("Exported to inventory_export.csv");
        });

        sortAscOpt.setOnMouseClicked(e -> {
            selectOptionLabel(sortAscOpt);
            inventoryManager.sortByPrice(true);
            refreshTable();
        });

        sortDescOpt.setOnMouseClicked(e -> {
            selectOptionLabel(sortDescOpt);
            inventoryManager.sortByPrice(false);
            refreshTable();
        });

        optionBox.getChildren().addAll(restockOpt, searchOpt, exportOpt, sortAscOpt, sortDescOpt);
        popup.getContent().add(optionBox);
    }

    public Popup getPopup() {
        return popup;
    }

    private void setupTable() {
        table = new TableView<>();
        TableColumn<InventoryItem, String> idCol = new TableColumn<>("Product ID");
        idCol.setCellValueFactory(cell -> new SimpleStringProperty(String.valueOf(cell.getValue().getId())));

        TableColumn<InventoryItem, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getName()));

        TableColumn<InventoryItem, String> categoryCol = new TableColumn<>("Category");
        categoryCol.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getCategory().toString()));

        TableColumn<InventoryItem, String> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(cell -> new SimpleStringProperty(String.format("%.2f", cell.getValue().getPrice())));

        TableColumn<InventoryItem, String> quantityCol = new TableColumn<>("Quantity");
        quantityCol.setCellValueFactory(cell -> new SimpleStringProperty(String.valueOf(cell.getValue().getQuantity())));

        table.getColumns().addAll(idCol, nameCol, categoryCol, priceCol, quantityCol);
        data = FXCollections.observableArrayList(inventoryManager.getItems());
        table.setItems(data);
    }

    private Label makeOptionLabel(String text, boolean top) {
        Label lbl = new Label(text);
        lbl.setPrefWidth(180);
        lbl.setPadding(new Insets(10, 15, 10, 15));
        lbl.setFont(Font.font(14));
        lbl.setTextFill(Color.BLACK);

        String baseColor = "#ffc0cb"; // baby pink
        String hoverColor = "#ff1493"; // deep pink
        String radius = top ? "10 10 0 0" : "0 0 10 10";

        lbl.setStyle("-fx-background-color:" + baseColor + ";" +
                "-fx-border-color: transparent transparent #e68a99 transparent;" +
                "-fx-border-width: 0 0 1 0;" +
                "-fx-background-radius:" + radius + ";" +
                "-fx-font-weight: bold;");

        lbl.setOnMouseEntered(e -> {
            lbl.setStyle("-fx-background-color:" + hoverColor + ";" +
                    "-fx-border-color: transparent transparent #cc5c6f transparent;" +
                    "-fx-background-radius:" + radius + ";" +
                    "-fx-font-weight: bold;");
            lbl.setTextFill(Color.WHITE);
        });

        lbl.setOnMouseExited(e -> {
            lbl.setStyle("-fx-background-color:" + baseColor + ";" +
                    "-fx-border-color: transparent transparent #e68a99 transparent;" +
                    "-fx-background-radius:" + radius + ";" +
                    "-fx-font-weight: bold;");
            lbl.setTextFill(Color.BLACK);
        });

        return lbl;
    }

    private void selectOptionLabel(Label lbl) {
        if (selectedOptionLabel != null) {
            selectedOptionLabel.setTextFill(Color.BLACK);
        }
        selectedOptionLabel = lbl;
        selectedOptionLabel.setTextFill(Color.WHITE);
    }

    private void showRestockPopup() {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.setTitle("Restock Item");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(15));
        layout.setStyle("-fx-background-color: lightgreen;");
        layout.setPrefWidth(300);

        TextField idField = new TextField();
        idField.setPromptText("Product ID");
        TextField amtField = new TextField();
        amtField.setPromptText("Amount");
        Button btn = new Button("Restock");

        Label msg = new Label();
        btn.setOnAction(e -> {
            try {
                int id = Integer.parseInt(idField.getText().trim());
                int amount = Integer.parseInt(amtField.getText().trim());
                inventoryManager.restockItem(id, amount);
                refreshTable();
                msg.setText("Item restocked successfully.");
            } catch (NumberFormatException ex) {
                msg.setText("Error: Check input. Please enter valid numbers.");
            }
        });

        layout.getChildren().addAll(idField, amtField, btn, msg);
        layout.setAlignment(Pos.CENTER);
        popupStage.setScene(new Scene(layout));
        popupStage.showAndWait();
    }

    private void showSearchPopup() {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.setTitle("Search Product");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(15));
        layout.setStyle("-fx-background-color: lightgreen;");
        layout.setPrefWidth(300);

        TextField searchField = new TextField();
        searchField.setPromptText("Enter Product ID");
        Label result = new Label();
        Button btn = new Button("Search");
        btn.setOnAction(e -> {
            try {
                int id = Integer.parseInt(searchField.getText().trim());
                InventoryItem item = inventoryManager.searchById(id);
                result.setText(item != null ? "Found: " + item.getName() + ", Qty: " + item.getQuantity() : "Item not found.");
            } catch (NumberFormatException ex) {
                result.setText("Error: Please enter a valid Product ID.");
            }
        });

        layout.getChildren().addAll(searchField, btn, result);
        layout.setAlignment(Pos.CENTER);
        popupStage.setScene(new Scene(layout));
        popupStage.showAndWait();
    }

    private void showMessagePopup(String msgText) {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.setTitle("Message");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(15));
        layout.setStyle("-fx-background-color: lightblue;");
        layout.setPrefWidth(300);

        Label msg = new Label(msgText);
        Button closeBtn = new Button("Close");
        closeBtn.setOnAction(e -> popupStage.close());

        layout.getChildren().addAll(msg, closeBtn);
        layout.setAlignment(Pos.CENTER);
        popupStage.setScene(new Scene(layout));
        popupStage.showAndWait();
    }

    private void refreshTable() {
        data.setAll(inventoryManager.getItems());
    }
}
