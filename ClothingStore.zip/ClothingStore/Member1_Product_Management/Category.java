package ClothingStore.Member1_Product_Management;

public enum Category {
    MEN,
    WOMEN,
    KIDS, CASUAL
}
