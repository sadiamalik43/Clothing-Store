/*package ClothingStore.Member1_Product_Management;

public class ConcreteProduct extends Product {
    public ConcreteProduct(int id, String name, double price) {
        super(id, name, price, null); 
    }

    @Override
    public String toString() {
        return String.format("Name: %s, ID: %d, Price: %.2f", getName(), getId(), getPrice());
    }
}*/

package ClothingStore.Member1_Product_Management;
public class ConcreteProduct extends Product {
    public ConcreteProduct(int id, String name, double price, Category category) {
        super(id, name, price, category);
    }
    @Override
    public String toString() {
        return String.format("Name: %s, ID: %d, Price: %.2f, Category: %s", getName(), getId(), getPrice(), getCategory());
    }
}
