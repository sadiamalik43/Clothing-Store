package ClothingStore.Member1_Product_Management;

public class Men extends Product {
    public Men(int id, String name, double price) {
        super(id, name, price, Category.MEN);
    }
}

