package ClothingStore.Member1_Product_Management;

public class Kids extends Product {
    public Kids(int id, String name, double price) {
        super(id, name, price, Category.KIDS);
    }
}
