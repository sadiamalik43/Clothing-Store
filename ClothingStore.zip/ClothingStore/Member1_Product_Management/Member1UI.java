package ClothingStore.Member1_Product_Management;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Popup;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Member1UI {

    private static final String FILE = "C:\\Users\\Dell\\Desktop\\JavaProjects\\firstjavafxproject\\src\\ClothingStore\\Member1_Product_Management\\PRODUCT.csv";

    private VBox optionBox;   
    private Label selectedOptionLabel = null; 
    private Stage mainStage; 
    private Stage addEditDialogStage = null; 
    private VBox contentBox; 
    private Stage searchStage = null;

    private BorderPane root;
    
    public Member1UI() {
        this(null);
    }

    public Member1UI(Stage mainStage) {
        this.mainStage = mainStage;
        buildUI();
    }

    public Popup getPopup() {
        Popup popup = new Popup();
        
       
        popup.getContent().add(root); 
        popup.setAutoHide(true);
        
        
        root.setPrefSize(220, 300);
        root.setMinSize(220, 300);    
        root.setMaxSize(220, 300);    
        root.setStyle("-fx-background-color: honeydew;");

        return popup;
    }

    private void buildUI() {
        root = new BorderPane();
        
        optionBox = new VBox();
        optionBox.setAlignment(Pos.TOP_LEFT);
        optionBox.setPadding(new Insets(0, 5, 5, 5));
        optionBox.setVisible(true);
        optionBox.setSpacing(0);  
        optionBox.setMinWidth(200);
        optionBox.setMaxWidth(200); 

        Label addOpt = makeConnectedOptionLabel("Add Product", true, false, false);
        Label editOpt = makeConnectedOptionLabel("Edit Product", false, true, false);
        Label searchOpt = makeConnectedOptionLabel("Search Product", false, false, true);

        addOpt.setOnMouseClicked(e -> {
            selectOptionLabel(addOpt);
            openAddEditDialog("Add Product", true);
        });
        editOpt.setOnMouseClicked(e -> {
            selectOptionLabel(editOpt);
            openAddEditDialog("Edit Product", false);
        });
        searchOpt.setOnMouseClicked(e -> {
            selectOptionLabel(searchOpt);
            openSearchBox();
        });

        optionBox.getChildren().addAll(addOpt, editOpt, searchOpt);

        
        VBox sideBar = new VBox();
        sideBar.setAlignment(Pos.TOP_CENTER);
        sideBar.setPadding(new Insets(20));
        root.setLeft(sideBar);

        
        HBox center = new HBox(optionBox);
        root.setCenter(center);
    }

    
    public Node getContent() {
        return root;
    }

    private Button makeSideButton(String text, double width, double height) {
        Button b = new Button(text);
        b.setMinWidth(width);
        b.setPrefHeight(height);
        b.setStyle("-fx-background-color:#d0f0d0;-fx-border-color:#4f7f4f;-fx-text-fill:#002147;" +
                "-fx-background-radius:12;-fx-border-radius:12;-fx-font-weight:bold;-fx-font-size:16px;");
        b.addEventHandler(MouseEvent.MOUSE_ENTERED, ev -> b.setStyle("-fx-background-color:#c2e8c2;-fx-border-color:#4f7f4f;-fx-text-fill:#002147;" +
                "-fx-background-radius:12;-fx-border-radius:12;-fx-font-weight:bold;-fx-font-size:16px;"));
        b.addEventHandler(MouseEvent.MOUSE_EXITED, ev -> b.setStyle("-fx-background-color:#d0f0d0;-fx-border-color:#4f7f4f;-fx-text-fill:#002147;" +
                "-fx-background-radius:12;-fx-border-radius:12;-fx-font-weight:bold;-fx-font-size:16px;"));
        return b;
    }

    private Label makeConnectedOptionLabel(String text, boolean top, boolean middle, boolean bottom) {
        Label lbl = new Label(text);
        lbl.setPrefWidth(160);
        lbl.setPadding(new Insets(10, 15, 10, 15));
        lbl.setFont(Font.font(14));
        lbl.setTextFill(Color.BLACK);
        
        String baseColor = "#ffc0cb";
        String hoverColor = "#ff1493";

        String radius;
        if (top) radius = "10 10 0 0";
        else if (middle) radius = "0";
        else radius = "0 0 10 10";

        lbl.setStyle("-fx-background-color:" + baseColor + ";" +
                "-fx-border-color: transparent transparent #e68a99 transparent;" +
                "-fx-border-width: 0 0 1 0;" +
                "-fx-background-radius:" + radius + ";" +
                "-fx-border-radius:" + radius + ";" +
                "-fx-font-weight: bold;");

        lbl.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
            if (lbl != selectedOptionLabel) {
                lbl.setStyle("-fx-background-color:" + hoverColor + ";" +
                        "-fx-border-color: transparent transparent #cc5c6f transparent;" +
                        "-fx-border-width: 0 0 1 0;" +
                        "-fx-background-radius:" + radius + ";" +
                        "-fx-border-radius:" + radius + ";" +
                        "-fx-font-weight: bold;");
                lbl.setTextFill(Color.WHITE);
            }
        });
        lbl.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
            if (lbl != selectedOptionLabel) {
                lbl.setStyle("-fx-background-color:" + baseColor + ";" +
                        "-fx-border-color: transparent transparent #e68a99 transparent;" +
                        "-fx-border-width: 0 0 1 0;" +
                        "-fx-background-radius:" + radius + ";" +
                        "-fx-border-radius:" + radius + ";" +
                        "-fx-font-weight: bold;");
                lbl.setTextFill(Color.BLACK);
            }
        });
        return lbl;
    }

    private void selectOptionLabel(Label lbl) {
        clearOptionSelection();
        selectedOptionLabel = lbl;

        String radius;
        int idx = optionBox.getChildren().indexOf(lbl);
        if (idx == 0) radius = "10 10 0 0";
        else if (idx == 1) radius = "0";
        else radius = "0 0 10 10";

        lbl.setStyle("-fx-background-color:#bf4069;" +
                "-fx-border-color: transparent transparent transparent transparent;" +
                "-fx-background-radius:" + radius + ";" +
                "-fx-font-weight:bold;");
        lbl.setTextFill(Color.WHITE);
    }

    private void clearOptionSelection() {
        if (selectedOptionLabel != null) {
            int idx = optionBox.getChildren().indexOf(selectedOptionLabel);
            boolean top = (idx == 0);
            boolean middle = (idx == 1);
            boolean bottom = (idx == 2);
            Label lbl = selectedOptionLabel;
            String baseColor = "#ffc0cb";
            String radius;
            if (top) radius = "10 10 0 0";
            else if (middle) radius = "0";
            else radius = "0 0 10 10";

            lbl.setStyle("-fx-background-color:" + baseColor + ";" +
                    "-fx-border-color: transparent transparent #e68a99 transparent;" +
                    "-fx-border-width: 0 0 1 0;" +
                    "-fx-background-radius:" + radius + ";" +
                    "-fx-border-radius:" + radius + ";" +
                    "-fx-font-weight: bold;");
            lbl.setTextFill(Color.BLACK);
            selectedOptionLabel = null;
        }
    }

   
    private void openAddEditDialog(String title, boolean addMode) {
        if (addEditDialogStage != null) {
            addEditDialogStage.close();
        }

        addEditDialogStage = new Stage();
        if (mainStage != null) addEditDialogStage.initOwner(mainStage);
        addEditDialogStage.initModality(Modality.APPLICATION_MODAL);
        addEditDialogStage.setTitle(title);
        addEditDialogStage.setWidth(380);
        addEditDialogStage.setHeight(380);

        BorderPane pane = new BorderPane();
        pane.setStyle("-fx-background-color: lightgreen;"); 
        
        contentBox = new VBox(10);
        contentBox.setPadding(new Insets(15));
        contentBox.setAlignment(Pos.CENTER_LEFT);

        TextField name = new TextField();
        TextField id = new TextField();
        TextField cat = new TextField();
        TextField price = new TextField();

        double fieldWidth = 240;
        name.setPrefWidth(fieldWidth);
        id.setPrefWidth(fieldWidth);
        cat.setPrefWidth(fieldWidth);
        price.setPrefWidth(fieldWidth);
        name.setPromptText("Name");
        name.setStyle("-fx-prompt-text-fill: #DB7093; -fx-background-color: white;"); 
        id.setStyle("-fx-prompt-text-fill: #DB7093; -fx-background-color: white;"); 
        cat.setPromptText("Category");
        cat.setStyle("-fx-prompt-text-fill: #DB7093; -fx-background-color: white;"); 
        price.setPromptText("Price");
        price.setStyle("-fx-prompt-text-fill: #DB7093; -fx-background-color: white;"); 

        if (addMode) {
            Button addBtn = dullMustardButton("Add");
            addBtn.setOnAction(e -> {
                try (FileWriter w = new FileWriter(FILE, true)) {
                    w.write(name.getText() + "," + id.getText() + "," + cat.getText().toUpperCase() + "," + price.getText() + "\n");
                    alert("Added");
                    addEditDialogStage.close();
                } catch (Exception ex) {
                    alert("Write error"+ex.getMessage());
                }
            });
            contentBox.getChildren().addAll(name, id, cat, price, addBtn);
        } else {
            TextField target = new TextField();
            target.setPrefWidth(fieldWidth);
            target.setPromptText("Existing ID");
            target.setStyle("-fx-prompt-text-fill: #DB7093; -fx-background-color: white;"); // White background
            name.setPromptText("New Name");
            id.setPromptText("New ID");
            cat.setPromptText("New Category");
            price.setPromptText("New Price");

            Button updateBtn = dullMustardButton("Update");
            updateBtn.setOnAction(e -> {
                try {
                    BufferedReader r = new BufferedReader(new FileReader(FILE));
                    List<String> lines = new ArrayList<>();
                    String hdr = r.readLine();
                    lines.add(hdr);
                    String ln;
                    boolean found = false;
                    while ((ln = r.readLine()) != null) {
                        String[] p = ln.split(",");
                        if (p.length >= 4 && p[1].trim().equals(target.getText().trim())) {
                            lines.add(name.getText() + "," + id.getText() + "," + cat.getText().toUpperCase() + "," + price.getText());
                            found = true;
                        } else lines.add(ln);
                    }
                    r.close();
                    if (!found) {
                        alert("ID not found");
                        return;
                    }
                    BufferedWriter w = new BufferedWriter(new FileWriter(FILE));
                    for (String l : lines) {
                        w.write(l);
                        w.newLine();
                    }
                    w.close();
                    alert("Updated");
                    addEditDialogStage.close();
                } catch (Exception ex) {
                    alert("Error:"+ex.getMessage());
                }
            });
            contentBox.getChildren().addAll(target, name, id, cat, price, updateBtn);
        }

        pane.setCenter(contentBox);

        Scene scene = new Scene(pane);
        addEditDialogStage.setScene(scene);
        addEditDialogStage.show();
    }

    
    private Button dullMustardButton(String txt) {
        Button b = new Button(txt);
        String dullMustard = "#CFAE6E"; 
        b.setStyle("-fx-background-color:" + dullMustard + "; -fx-text-fill: black; -fx-font-weight:bold; -fx-font-size:14px;");
        b.addEventHandler(MouseEvent.MOUSE_ENTERED, ev -> b.setStyle("-fx-background-color:#b8995a; -fx-text-fill: black; -fx-font-weight:bold; -fx-font-size:14px;"));
        b.addEventHandler(MouseEvent.MOUSE_EXITED, ev -> b.setStyle("-fx-background-color:" + dullMustard + "; -fx-text-fill: black; -fx-font-weight:bold; -fx-font-size:14px;"));
        return b;
    }

    private void closeAddEditDialog() {
        if (addEditDialogStage != null) {
            addEditDialogStage.close();
            addEditDialogStage = null;
        }
    }

    private void openSearchBox() {
        if (searchStage != null) {
            searchStage.close();
        }
        searchStage = new Stage();
        if (mainStage != null) searchStage.initOwner(mainStage);
        searchStage.initModality(Modality.NONE);
        searchStage.setTitle("Search Product");
        searchStage.setWidth(350);
        searchStage.setHeight(320);

        BorderPane pane = new BorderPane();
        pane.setStyle("-fx-background-color: lightgreen; -fx-border-radius: 8; -fx-background-radius: 8;");

        VBox box = new VBox(10);
        box.setPadding(new Insets(15));
        box.setAlignment(Pos.CENTER_LEFT);

        TextField idFld = new TextField();
        idFld.setPrefWidth(240);
        idFld.setPromptText("ID");
        idFld.setStyle("-fx-prompt-text-fill: #DB7093; -fx-background-color: white;"); // White background

        Label res = new Label();
        res.setWrapText(true);
        res.setStyle("-fx-text-fill:black; -fx-font-weight: normal; -fx-padding:10 0 0 0;");

        Button searchBtn = yellowButton("Search");
        searchBtn.setOnAction(e -> {
            try (BufferedReader r = new BufferedReader(new FileReader(FILE))) {
                r.readLine();
                String ln;
                boolean found = false;
                while ((ln = r.readLine()) != null) {
                    String[] p = ln.split(",");
                    if (p.length >= 4 && p[1].trim().equals(idFld.getText().trim())) {
                        res.setText("Name: " + p[0] + "\nID: " + p[1] + "\nCat: " + p[2] + "\nPrice: " + p[3]);
                        found = true;
                        break;
                    }
                }
                if (!found) res.setText("Not found");
            } catch (Exception ex) {
                res.setText("Error"+ex.getMessage());
            }
        });

        box.getChildren().addAll(idFld, searchBtn, res);
        pane.setCenter(box);

        Scene scene = new Scene(pane);
        searchStage.setScene(scene);

        
        if (mainStage != null) {
            searchStage.setX(mainStage.getX() + mainStage.getWidth() + 10);
            searchStage.setY(mainStage.getY() + 50);
        }

        searchStage.show();
    }

    private void closeSearchBox() {
        if (searchStage != null) {
            searchStage.close();
            searchStage = null;
        }
    }

    private Button yellowButton(String txt) {
        Button b = new Button(txt);
        b.setStyle("-fx-background-color:white;-fx-border-color:yellow;-fx-font-weight:bold;-fx-font-size:14px;");
        b.addEventHandler(MouseEvent.MOUSE_ENTERED, ev -> b.setStyle("-fx-background-color:yellow;-fx-border-color:#daa520;-fx-font-weight:bold;-fx-font-size:14px;"));
        b.addEventHandler(MouseEvent.MOUSE_EXITED, ev -> b.setStyle("-fx-background-color:white;-fx-border-color:yellow;-fx-font-weight:bold;-fx-font-size:14px;"));
        return b;
    }

    private void alert(String msg) {
        new Alert(Alert.AlertType.INFORMATION, msg).showAndWait();
    }
}

