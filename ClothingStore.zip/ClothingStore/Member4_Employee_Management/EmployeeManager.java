package ClothingStore.Member4_Employee_Management;

import java.io.*;
import java.util.*;

public class EmployeeManager {
    private List<Employee> employeeList = new ArrayList<>();

    // --- IMPORTANT: Adjust this file path to your actual project structure ---
    private static final String CSV_FILE_PATH = "C:\\Users\\Dell\\Desktop\\JavaProjects\\firstjavafxproject\\src\\ClothingStore\\Member4_Employee_Management\\EMPLOYEES.csv";


    public EmployeeManager() {
        loadEmployeesFromCSV(); // Load data when EmployeeManager is instantiated
    }

    // Loads employee data from the CSV file
    private void loadEmployeesFromCSV() {
        employeeList.clear(); // Clear existing list before loading
        try (BufferedReader reader = new BufferedReader(new FileReader(CSV_FILE_PATH))) {
            String line;
            if ((line = reader.readLine()) != null && line.trim().equals("Name,ID,Email,Role")) {
                // Skip header line if it matches
            } else {
                // If no header or incorrect header, consider the first line as data or log a warning
                if (line != null) { // Process the first line if it's not the expected header
                     processEmployeeLine(line);
                }
            }

            while ((line = reader.readLine()) != null) {
                processEmployeeLine(line);
            }
        } catch (FileNotFoundException e) {
            System.out.println("EMPLOYEES.csv not found. A new one will be created on save.");
            // This is normal for the first run; no error needed, just informative message
        } catch (IOException e) {
            System.err.println("Error loading employees from CSV: " + e.getMessage());
        }
    }

    private void processEmployeeLine(String line) {
        String[] parts = line.split(",");
        if (parts.length == 4) { // Name,ID,Email,Role
            String name = parts[0].trim();
            String id = parts[1].trim();
            String email = parts[2].trim();
            String roleName = parts[3].trim();

            // Use the Employee constructor that accepts an existing ID
            Employee emp = new Employee(id, name, email, new Role(roleName));
            employeeList.add(emp);
        } else {
            System.err.println("Skipping malformed CSV line: " + line);
        }
    }

    // Saves current employee data to the CSV file
    private void saveEmployeesToCSV() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CSV_FILE_PATH))) {
            // Write header
            writer.write("Name,ID,Email,Role\n");
            for (Employee e : employeeList) {
                writer.write(e.getName() + "," + e.getId() + "," + e.getEmail() + "," + e.getRole().getRoleName() + "\n");
            }
        } catch (IOException e) {
            System.err.println("Error saving employees to CSV: " + e.getMessage());
        }
    }

    public void addEmployee(Employee e) {
        employeeList.add(e);
        saveEmployeesToCSV(); // Save after adding
    }

    public void removeEmployee(String id) {
        boolean removed = employeeList.removeIf(e -> e.getId().equals(id));
        if (removed) {
            saveEmployeesToCSV(); // Save after removing
        }
    }

    public Employee findById(String id) {
        for (Employee e : employeeList) {
            if (e.getId().equals(id)) return e;
        }
        return null;
    }

    // Call this after an employee's properties (name, email, role) have been modified directly on the object found by findById
    public void updateEmployeeInList() {
        saveEmployeesToCSV(); // Just save the entire list, as the object in memory has been modified
    }

    public void listEmployees() { // Used by InteractiveEmployeeManager (console-based)
        for (Employee e : employeeList) {
            System.out.println(e);
        }
    }

    // Returns a copy of the list of all employees for UI display
    public List<Employee> getAllEmployees() {
        return new ArrayList<>(employeeList);
    }
}