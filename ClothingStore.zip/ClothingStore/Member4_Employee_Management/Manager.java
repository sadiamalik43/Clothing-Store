package ClothingStore.Member4_Employee_Management;
public class Manager extends Employee {
    public Manager(String id, String name, String email) {
        super(id, name, email, new Role("Manager")); // Pass the ID to the superclass
    }
    public void approveRequest(String requestId) {
        System.out.println("Manager " + name + " approved request: " + requestId);
    }
}