package ClothingStore.Member4_Employee_Management;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.scene.Scene;

import java.util.List;

public class Member4UI {

    private VBox optionBox;
    private Label selectedOptionLabel = null;
    private Popup popup;

    // EmployeeManager instance to connect UI with backend
    private EmployeeManager employeeManager;

    public Member4UI(EmployeeManager employeeManager) {
        this.employeeManager = employeeManager;
        popup = new Popup();
        popup.setAutoHide(true);
        buildPopup();
    }

    private void buildPopup() {
        optionBox = new VBox();
        optionBox.setAlignment(Pos.TOP_LEFT);
        optionBox.setPadding(new Insets(0, 5, 5, 5));
        optionBox.setSpacing(0);

        Label addOpt = makeOptionLabel("Add Employee", true);
        Label editOpt = makeOptionLabel("Edit Employee", false);
        Label searchOpt = makeOptionLabel("Search Employee", false);
        Label listAllOpt = makeOptionLabel("List All Employees", false); // NEW option

        addOpt.setOnMouseClicked(e -> {
            selectOptionLabel(addOpt);
            showAddEmployeePopup();
            popup.hide();
        });

        editOpt.setOnMouseClicked(e -> {
            selectOptionLabel(editOpt);
            showEditEmployeePopup();
            popup.hide();
        });

        searchOpt.setOnMouseClicked(e -> {
            selectOptionLabel(searchOpt);
            showSearchEmployeePopup();
            popup.hide();
        });

        // NEW event listener for "List All Employees"
        listAllOpt.setOnMouseClicked(e -> {
            selectOptionLabel(listAllOpt);
            showListAllEmployeesPopup(); // Call the new method
            popup.hide();
        });

        // Add all options to the VBox
        optionBox.getChildren().addAll(addOpt, editOpt, searchOpt, listAllOpt); // Added listAllOpt
        popup.getContent().add(optionBox);
    }

    public Popup getPopup() {
        return popup;
    }

    private Label makeOptionLabel(String text, boolean top) {
        Label lbl = new Label(text);
        lbl.setPrefWidth(160);
        lbl.setPadding(new Insets(10, 15, 10, 15));
        lbl.setFont(Font.font(14));
        lbl.setTextFill(Color.BLACK);

        String baseColor = "#ffc0cb"; // baby pink
        String hoverColor = "#ff1493"; // deep pink
        String radius = top ? "10 10 0 0" : "0 0 10 10"; // Only top label has curved top corners

        lbl.setStyle("-fx-background-color:" + baseColor + ";" +
                "-fx-border-color: transparent transparent #e68a99 transparent;" +
                "-fx-border-width: 0 0 1 0;" +
                "-fx-background-radius:" + radius + ";" +
                "-fx-font-weight: bold;");

        lbl.setOnMouseEntered(e -> {
            lbl.setStyle("-fx-background-color:" + hoverColor + ";" +
                    "-fx-border-color: transparent transparent #cc5c6f transparent;" +
                    "-fx-background-radius:" + radius + ";" +
                    "-fx-font-weight: bold;");
            lbl.setTextFill(Color.WHITE);
        });

        lbl.setOnMouseExited(e -> {
            // Restore to base color unless it's the selected option
            if (lbl != selectedOptionLabel) {
                 lbl.setStyle("-fx-background-color:" + baseColor + ";" +
                     "-fx-border-color: transparent transparent #e68a99 transparent;" +
                     "-fx-border-width: 0 0 1 0;" +
                     "-fx-background-radius:" + radius + ";" +
                     "-fx-font-weight: bold;");
                 lbl.setTextFill(Color.BLACK);
            } else {
                lbl.setStyle("-fx-background-color:" + hoverColor + ";" + // Keep selected label highlighted
                     "-fx-border-color: transparent transparent #cc5c6f transparent;" +
                     "-fx-background-radius:" + radius + ";" +
                     "-fx-font-weight: bold;");
                lbl.setTextFill(Color.WHITE);
            }
        });

        return lbl;
    }

    private void selectOptionLabel(Label lbl) {
        if (selectedOptionLabel != null) {
            // Restore previous selected label's style
            String baseColor = "#ffc0cb";
            boolean top = selectedOptionLabel.getText().equals("Add Employee"); // Simple way to check if top
            String radius = top ? "10 10 0 0" : "0 0 10 10";
            selectedOptionLabel.setTextFill(Color.BLACK);
            selectedOptionLabel.setStyle("-fx-background-color:" + baseColor + ";" +
                    "-fx-border-color: transparent transparent #e68a99 transparent;" +
                    "-fx-border-width: 0 0 1 0;" +
                    "-fx-background-radius:" + radius + ";" +
                    "-fx-font-weight: bold;");
        }
        selectedOptionLabel = lbl;
        selectedOptionLabel.setTextFill(Color.WHITE);
        // Apply hover style to selected label to keep it distinct
        String hoverColor = "#ff1493";
        boolean top = selectedOptionLabel.getText().equals("Add Employee");
        String radius = top ? "10 10 0 0" : "0 0 10 10";
        selectedOptionLabel.setStyle("-fx-background-color:" + hoverColor + ";" +
                "-fx-border-color: transparent transparent #cc5c6f transparent;" +
                "-fx-background-radius:" + radius + ";" +
                "-fx-font-weight: bold;");
    }

    private void showAddEmployeePopup() {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.setTitle("Add Employee");

        TextField idField = new TextField();
        idField.setPromptText("ID (must be unique)");

        TextField nameField = new TextField();
        nameField.setPromptText("Name");

        TextField emailField = new TextField();
        emailField.setPromptText("Email");

        TextField roleField = new TextField();
        roleField.setPromptText("Role");

        Button addButton = new Button("Add");

        Label feedback = new Label();
        feedback.setTextFill(Color.RED); // Default to red for potential errors

        addButton.setOnAction(e -> {
            String id = idField.getText().trim();
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String roleName = roleField.getText().trim();

            if (id.isEmpty() || name.isEmpty() || email.isEmpty() || roleName.isEmpty()) {
                feedback.setTextFill(Color.RED);
                feedback.setText("All fields are required.");
                return;
            }

            Employee emp = new Employee(id, name, email, new Role(roleName));
            employeeManager.addEmployee(emp);

            feedback.setTextFill(Color.GREEN);
            feedback.setText("Employee added successfully!\nID: " + emp.getId() + "\n(Copy this ID for editing/searching)");

            idField.clear();
            nameField.clear();
            emailField.clear();
            roleField.clear();
            // popupStage.close(); // Uncomment to close popup after adding
        });

        VBox layout = new VBox(10, idField, nameField, emailField, roleField, addButton, feedback);
        layout.setPadding(new Insets(15));
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: #e0ffe0;"); // Lighter green for add popup
        layout.setPrefWidth(300);

        popupStage.setScene(new Scene(layout));
        popupStage.showAndWait();
    }

    private void showEditEmployeePopup() {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.setTitle("Edit Employee");

        TextField idField = new TextField();
        idField.setPromptText("Employee ID to edit");

        TextField nameField = new TextField();
        nameField.setPromptText("New Name (leave blank to keep current)");

        TextField emailField = new TextField(); // Added email field for editing
        emailField.setPromptText("New Email (leave blank to keep current)");

        TextField roleField = new TextField();
        roleField.setPromptText("New Role (leave blank to keep current)");

        Button updateButton = new Button("Update");

        Label feedback = new Label();
        feedback.setTextFill(Color.RED);

        updateButton.setOnAction(e -> {
            String id = idField.getText().trim();
            String newName = nameField.getText().trim();
            String newEmail = emailField.getText().trim(); // Get new email
            String newRole = roleField.getText().trim();

            if (id.isEmpty()) {
                feedback.setText("Employee ID is required.");
                return;
            }

            Employee emp = employeeManager.findById(id);
            if (emp == null) {
                feedback.setText("Employee with ID '" + id + "' not found. No changes applied.");
                return;
            }

            // Update fields only if new values are provided
            if (!newName.isEmpty()) {
                emp.setName(newName);
            }
            if (!newEmail.isEmpty()) { // Apply new email
                emp.setEmail(newEmail);
            }
            if (!newRole.isEmpty()) {
                emp.setRole(new Role(newRole));
            }

            employeeManager.updateEmployeeInList(); // Tell manager to save changes

            feedback.setTextFill(Color.GREEN);
            feedback.setText("Employee updated successfully!");
            // popupStage.close(); // Uncomment to close popup after updating
        });

        VBox layout = new VBox(10, idField, nameField, emailField, roleField, updateButton, feedback); // Added emailField
        layout.setPadding(new Insets(15));
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: #fff0e0;"); // Lighter orange for edit popup
        layout.setPrefWidth(300);

        popupStage.setScene(new Scene(layout));
        popupStage.showAndWait();
    }

    private void showSearchEmployeePopup() {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.setTitle("Search Employee");

        TextField idField = new TextField();
        idField.setPromptText("Employee ID to search");

        Button searchButton = new Button("Search");

        Label resultLabel = new Label();
        resultLabel.setWrapText(true);
        resultLabel.setTextFill(Color.BLACK); // Default color for result, errors will be red

        searchButton.setOnAction(e -> {
            String id = idField.getText().trim();

            if (id.isEmpty()) {
                resultLabel.setTextFill(Color.RED);
                resultLabel.setText("Employee ID is required.");
                return;
            }

            Employee emp = employeeManager.findById(id);
            if (emp == null) {
                resultLabel.setTextFill(Color.RED);
                resultLabel.setText("Employee with ID '" + id + "' not found.");
            } else {
                resultLabel.setTextFill(Color.BLACK);
                resultLabel.setText("Found Employee:\n" + emp.toString()); // Uses improved toString()
            }
        });

        VBox layout = new VBox(10, idField, searchButton, resultLabel);
        layout.setPadding(new Insets(15));
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: #e0e0ff;"); // Lighter blue for search popup
        layout.setPrefWidth(300);

        popupStage.setScene(new Scene(layout));
        popupStage.showAndWait();
    }

    // NEW Method to display all employees in a popup
    private void showListAllEmployeesPopup() {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.setTitle("All Employees");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(15));
        layout.setAlignment(Pos.TOP_LEFT);
        layout.setStyle("-fx-background-color: #f0f0f0;"); // Neutral background for list
        layout.setPrefWidth(500); // Increased width to show full UUIDs

        Label title = new Label("Current Employees:");
        title.setFont(Font.font(16));
        title.setStyle("-fx-font-weight: bold;");
        layout.getChildren().add(title);

        List<Employee> employees = employeeManager.getAllEmployees();

        if (employees.isEmpty()) {
            Label noEmployees = new Label("No employees found. Add some using 'Add Employee' first!");
            layout.getChildren().add(noEmployees);
        } else {
            for (Employee emp : employees) {
                // Display each employee using the enhanced toString()
                Label employeeDetails = new Label(emp.toString() + "\n");
                employeeDetails.setWrapText(true); // Allow text to wrap if too long
                layout.getChildren().add(employeeDetails);
            }
        }

        popupStage.setScene(new Scene(layout));
        popupStage.showAndWait();
    }
}

