package ClothingStore.Member4_Employee_Management;

public class Main4 {
    public static void main(String[] args) {
        InteractiveEmployeeManager employeeManagerUI = new InteractiveEmployeeManager();
        employeeManagerUI.run();
    }
}
