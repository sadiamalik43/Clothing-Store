package ClothingStore.Member4_Employee_Management;

import java.util.Scanner;

public class InteractiveEmployeeManager {
    private EmployeeManager manager = new EmployeeManager();
    private Scanner sc = new Scanner(System.in);

    public void run() {
        int choice;
        do {
            System.out.println("\n--- Clothing Store Employee Management ---");
            System.out.println("1. Add Employee");
            System.out.println("2. Add Manager");
            System.out.println("3. Remove Employee by ID");
            System.out.println("4. View All Employees");
            System.out.println("5. Exit Employee Management");
            System.out.print("Enter your choice: ");
            choice = Integer.parseInt(sc.nextLine());

            switch (choice) {
                case 1:
                    addEmployee();
                    break;
                case 2:
                    addManager();
                    break;
                case 3:
                    removeEmployee();
                    break;
                case 4:
                    listEmployees();
                    break;
                case 5:
                    System.out.println("Exiting Employee Management.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    private void addEmployee() {
        System.out.println("Enter ID:");
        String id=sc.nextLine();
        System.out.print("Enter employee name: ");
        String name = sc.nextLine();
        System.out.print("Enter email: ");
        String email = sc.nextLine();
        System.out.print("Enter role: ");
        String roleName = sc.nextLine();

        Employee e = new Employee(id,name, email, new Role(roleName));
        manager.addEmployee(e);
        System.out.println("Employee added successfully!");
    }

    private void addManager() {
    System.out.print("Enter ID: ");
    String id = sc.nextLine(); 
    System.out.print("Enter manager name: ");
    String name = sc.nextLine();
    System.out.print("Enter email: ");
    String email = sc.nextLine();

    Manager m = new Manager(id, name, email); 
    manager.addEmployee(m);
    System.out.println("Manager added successfully!");
}


    private void removeEmployee() {
        System.out.print("Enter employee ID to remove: ");
        String id = sc.nextLine();

        Employee e = manager.findById(id);
        if (e != null) {
            manager.removeEmployee(id);
            System.out.println("Employee removed successfully.");
        } else {
            System.out.println("Employee with ID " + id + " not found.");
        }
    }

    private void listEmployees() {
        System.out.println("\n--- Employee List ---");
        manager.listEmployees();
    }
}
